﻿angular.module('wiz.markdown', [
	'ngSanitize'
]);