angular.module('demo', [
	'demo.features.home'
]);