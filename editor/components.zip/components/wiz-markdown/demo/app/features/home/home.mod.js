angular.module('demo.features.home', [
	'ngSanitize',
	'wiz.markdown'
]);